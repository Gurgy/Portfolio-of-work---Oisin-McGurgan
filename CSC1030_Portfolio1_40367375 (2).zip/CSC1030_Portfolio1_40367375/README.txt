File contains example of my work using HTML

Task 1 required me to create a CV
Task 2 required me to create a page of something of personal interest to myself