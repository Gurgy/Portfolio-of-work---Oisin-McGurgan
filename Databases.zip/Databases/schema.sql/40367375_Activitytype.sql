-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 13, 2023 at 01:26 PM
-- Server version: 10.4.26-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `omcgurgan01`
--

-- --------------------------------------------------------

--
-- Table structure for table `40367375_Activitytype`
--

CREATE TABLE `40367375_Activitytype` (
  `acID` bigint(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `venueID` int(11) DEFAULT NULL,
  `spendID` bigint(20) DEFAULT NULL,
  `status` varchar(20) NOT NULL,
  `started` date NOT NULL,
  `ended` date DEFAULT NULL,
  `internal` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `40367375_Activitytype`
--
ALTER TABLE `40367375_Activitytype`
  ADD PRIMARY KEY (`acID`),
  ADD KEY `title` (`title`),
  ADD KEY `venueID` (`venueID`),
  ADD KEY `spendID` (`spendID`),
  ADD KEY `status` (`status`),
  ADD KEY `internal` (`internal`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `40367375_Activitytype`
--
ALTER TABLE `40367375_Activitytype`
  MODIFY `acID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `40367375_Activitytype`
--
ALTER TABLE `40367375_Activitytype`
  ADD CONSTRAINT `fk_activity_spend1` FOREIGN KEY (`spendID`) REFERENCES `40367375_Spending` (`spendID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_activity_venue1` FOREIGN KEY (`venueID`) REFERENCES `40367375_Venue` (`venueID`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
