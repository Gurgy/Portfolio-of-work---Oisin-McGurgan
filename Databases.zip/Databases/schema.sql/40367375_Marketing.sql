-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 13, 2023 at 01:27 PM
-- Server version: 10.4.26-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `omcgurgan01`
--

-- --------------------------------------------------------

--
-- Table structure for table `40367375_Marketing`
--

CREATE TABLE `40367375_Marketing` (
  `acID` bigint(20) NOT NULL,
  `staffID` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `40367375_Marketing`
--
ALTER TABLE `40367375_Marketing`
  ADD PRIMARY KEY (`acID`,`staffID`),
  ADD KEY `acID` (`acID`),
  ADD KEY `staffID` (`staffID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `40367375_Marketing`
--
ALTER TABLE `40367375_Marketing`
  ADD CONSTRAINT `fk_marketing_activity1` FOREIGN KEY (`acID`) REFERENCES `40367375_Activitytype` (`acID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_marketing_staff1` FOREIGN KEY (`staffID`) REFERENCES `40367375_Staff` (`staffID`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
