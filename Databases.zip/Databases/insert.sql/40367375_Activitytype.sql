-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 13, 2023 at 01:34 PM
-- Server version: 10.4.26-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `omcgurgan01`
--

--
-- Dumping data for table `40367375_Activitytype`
--

INSERT INTO `40367375_Activitytype` (`acID`, `title`, `venueID`, `spendID`, `status`, `started`, `ended`, `internal`) VALUES
(1, 'New Programme Promotion', 1, 1, 'On Going', '2021-02-01', NULL, 1),
(2, 'Coding Competition', 2, 2, 'Finished', '2019-01-01', '2019-01-30', 1),
(3, 'Drone Design Workshop', 1, 3, 'Finished', '2018-11-14', '2018-12-14', 1),
(4, 'Welcome Party', 3, 4, 'Planning', '2023-01-18', '2023-01-30', 1),
(5, 'Summer Postgraduate BBQ', 1, 5, 'Finished', '2016-06-07', '2016-06-08', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
