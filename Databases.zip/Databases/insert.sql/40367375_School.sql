-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 13, 2023 at 01:37 PM
-- Server version: 10.4.26-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `omcgurgan01`
--

--
-- Dumping data for table `40367375_School`
--

INSERT INTO `40367375_School` (`schID`, `schoolName`, `Faculty`, `HODName`, `Address`) VALUES
(1, 'EEECS', 'School of EEE and Computer Science', 'Paul Smith', '16 Malone Road, Belfast BT9 5BN'),
(2, 'Mathematics', 'School of Mathematics and Physics', 'Julie Clark', 'Main Physics Building University Road, Belfast BT7 1NN'),
(3, 'MAE', 'School of Mechanical and Aerospace Engineering', 'Andrew White', 'Ashby Building, Stranmillis Road, Belfast BT9 5AH'),
(4, 'Physics', 'School of Mathematics and Physics', 'Lee Anderson', 'Main Physics Building University Road, Belfast BT7 1NN'),
(5, 'Audio Engineering', 'School Of Arts, English and Languages', 'Peter Monash', '2 University Square, Belfast BT7 1NN'),
(6, 'Academic Writing', 'School Of Arts, English and Languages', 'Mary Lee', '2 University Square, Belfast BT7 1NN');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
