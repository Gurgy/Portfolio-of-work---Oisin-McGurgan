-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 13, 2023 at 01:38 PM
-- Server version: 10.4.26-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `omcgurgan01`
--

--
-- Dumping data for table `40367375_Student`
--

INSERT INTO `40367375_Student` (`StudentID`, `StudentName`, `DoB`, `HomeAddress`) VALUES
(1, 'Daniel Lee', '2000-05-13', '11 Martin Street'),
(2, 'Jenny Parry', '1997-06-15', '29 Orchard Ave'),
(3, 'Mohan Rashiv', '2002-09-15', '210 Kingston Street'),
(4, 'Laura Park', '1997-04-18', '56 Depak Park'),
(5, 'Levis Shepherd', '1999-12-23', '200 Johnson Ave'),
(6, 'Mary Carson', '2003-06-13', '189 Friedman Centers'),
(7, 'Alexander Murdock', '1996-04-18', '029 Hart Haven'),
(8, 'Kareem Coker', '1998-02-11', '4425 Lisa Station Apt. 314'),
(9, 'Harry Hurtado', '2001-02-02', '204 Jennifer Island'),
(10, 'Jose Abbott', '2002-09-28', '509 Powell Ways'),
(11, 'Daniel Willard', '2002-04-09', '0637 Brittany Station'),
(12, 'Bruce Clifton', '1998-03-26', '9742 Pineda Underpass'),
(13, 'Sandra Pack', '1997-09-23', '030 Renee Mills'),
(14, 'Chris Jones', '1997-12-02', '888 Nicholas Mission Suite 732'),
(15, 'Raymond Pauls', '2003-09-04', '777 Cynthia Shoals'),
(16, 'Lori Nelson', '1997-12-25', '5542 Harper Orchard Suite '),
(17, 'Jill Johnson', '2000-03-20', '030 Steven Hill'),
(18, 'Willie Dollar', '1998-04-23', '1969 Shannon Crest '),
(19, 'Larry Aldridge', '1997-12-06', '395 Miles Point'),
(20, 'Paul Smith', '2000-06-03', '9733 Jeffrey Shoals'),
(21, 'George Corbett', '2001-09-18', '651 Cervantes Heights'),
(22, 'Tracee Lipka', '2002-09-06', '05478 Powers Parks Apt.'),
(23, 'Ronald Wheeler', '1998-11-02', '501 Shelia Ways'),
(24, 'Ricardo Glory', '1998-07-16', '63660 Mark Landing Apt.'),
(25, 'John Yee', '1996-09-05', '345 Stephanie Stream'),
(26, 'Therese Tosh', '1996-07-23', '996 Lewis Mount'),
(27, 'Judith Loughmiller', '1998-03-09', '39253 Charles Rapids'),
(28, 'Leonard Sauer', '1997-01-09', '78814 Rice Locks'),
(29, 'Amber Brock', '1996-11-12', '3713 Rich Square Suite'),
(30, 'Dorothy Davidson', '1997-08-19', '653 Wilson Way'),
(31, 'Dexter Kowal', '1996-10-03', '6628 James Way'),
(32, 'John Holt', '1998-03-15', '0995 Victoria Squares Apt.'),
(33, 'Kelly Stewart', '1996-05-03', '9609 Troy Circle Suite'),
(34, 'Mark Sears', '1997-09-05', '3892 Jenkins Mall'),
(35, 'Paul Blackaby', '1996-12-20', '4765 Robertson Mews'),
(36, 'Mary Bronstein', '1997-07-03', '338 Lisa Place Suite 307'),
(37, 'Chris Mills', '1997-11-13', '705 Nicole Cliffs'),
(38, 'Matthew Anderson', '1997-05-04', '52905 Morrow Walks Suite 917'),
(39, 'Jennifer Alvarado', '1997-12-31', '015 Riggs Forks Suite 171'),
(40, 'Edward Hirsch', '1998-08-11', '3165 Morgan Hill'),
(41, 'Leon Adams', '1998-12-15', '648 Lori Courts'),
(42, 'Virginia Davis', '1998-05-04', '837 Walker Hollow'),
(43, 'Gene Hoover', '1998-05-23', '82671 Sara Wells'),
(44, 'Janie Wilkinson', '1998-07-19', '72020 Bruce Lane'),
(45, 'Phyllis Lei', '1997-07-13', '788 Shannon Estate'),
(46, 'Nicholas Keyes', '1997-12-06', '06677 Oneal Junction'),
(47, 'Victor Porter', '1998-10-05', 'USNS Johnson'),
(48, 'Kimberly Galindez', '1998-09-19', '67334 Donald Village Suite 741'),
(49, 'Margaret Smith', '1998-11-24', '5870 Christina Mountain'),
(50, 'Vera Park', '1998-06-24', '79723 Marc Lodge Suite 906'),
(51, 'Leigh Dillman', '1998-09-26', '676 Whitney Mission Apt. 038'),
(52, 'Wayne Crout', '1996-05-06', '76713 Tanner Village'),
(53, 'Isabelle Critchfield', '1997-11-25', '683 Hernandez Pine Road'),
(54, 'Leslie Briseno', '1998-11-19', '06660 Williams Isle Suite'),
(55, 'Brett Magano', '1998-02-08', '55116 Lloyd Port Apt.'),
(56, 'Susan Wilmoth', '1996-04-25', '4429 Marcia Centers Apt.'),
(57, 'Erika Parks', '1997-12-29', '392 Richard Light Suite'),
(58, 'Deborah Ramirez', '1998-12-21', '848 Freeman Viaduct Apt.'),
(59, 'Jill Andrade', '1996-10-19', '044 Thomas Throughway Suite'),
(60, 'David Silva', '1996-10-21', '14674 Dickson Forks'),
(61, 'Willis Abraham', '1997-09-26', '18569 John Courts'),
(62, 'Stanley Schiff', '1996-12-16', '489 Howell Place Suite '),
(63, 'Olga Lew', '1998-04-28', '9416 Joseph Valleys'),
(64, 'Belinda Xiong', '1998-11-09', '63800 Taylor Fords'),
(65, 'Jean Whittenbeck', '1998-04-26', '1449 Jenna Loaf'),
(66, 'George Johns', '1997-08-25', '5431 Blair Dam Suite'),
(67, 'Tonya Toomey', '1998-04-21', '5541 Thomas Expressway Apt.'),
(68, 'Wade Stolar', '1997-08-26', '340 Brian Overpass'),
(69, 'Aimee Doctor', '2000-11-03', '63162 Gonzalez Unions Apt.'),
(70, 'Miguel Barrett', '2000-06-02', '526 Melissa Stravenue Apt.'),
(71, 'Esther Mulloy', '2003-07-03', '1119 Joseph Motorway Suite'),
(72, 'John Rios', '1987-09-19', '518 Pamela Brook'),
(73, 'Rose Stanley', '1995-01-26', '03197 Debra Estate Apt.'),
(74, 'Billy Hayes', '1982-04-21', '99023 Kimberly Villages'),
(75, 'Carolina Gross', '1998-06-14', '2018 Tricia Stream'),
(76, 'Cynthia Patten', '2004-07-19', '5014 Leach Pines'),
(77, 'Lewis Johnson', '2002-07-06', '5591 Ball Shores Suite '),
(78, 'Amanda Dyer', '2001-09-11', '516 Kathryn Hollow'),
(79, 'Pamela Corson', '2000-10-08', '8454 Katherine Lights Suite'),
(80, 'Deloris Morrow', '2001-08-24', '826 Rhonda Dale'),
(81, 'Mary Park', '2002-07-27', '024 Cassidy Pike Suite'),
(82, 'Michael Carr', '1998-06-03', '63097 Tammy Heights Suite'),
(83, 'Martha Peno', '2002-08-18', '279 Richard Islands Suite'),
(84, 'Virgil Rilley', '2003-02-20', '850 Fritz Groves Apt.'),
(85, 'James Duran', '2003-04-10', '659 Crystal Walk Suite'),
(86, 'Michael Peters', '1992-06-11', '2176 Jones Views Apt.'),
(87, 'Jason Sibrel', '2000-05-28', '28400 Rachel Isle'),
(88, 'Alberta Coggan', '2001-01-23', '523 Olivia Green Suite'),
(89, 'Richard Wilcox', '1997-06-09', '4396 Stout Square'),
(90, 'Yvonne Tarver', '1999-03-30', '3725 Manuel River'),
(91, 'Leo Jennings', '2003-10-02', 'Unit 3562 Box 9200'),
(92, 'Darren Swank', '2004-05-26', '3626 Burgess Roads Suite'),
(93, 'Jeremy Clark', '1999-07-12', '913 Gerald Shore'),
(94, 'Robert Ackley', '1992-10-22', '452 Jeffery Landing Suite '),
(95, 'Neil Green', '1994-04-08', '692 Amanda Lock'),
(96, 'Cynthia Davis', '1998-11-19', '093 Alexandra Tunnel Suite'),
(97, 'Owen Taylor', '2001-05-26', '37850 Dawn Alley'),
(98, 'Benny King', '1992-01-17', '82762 Dean Hollow'),
(99, 'Danielle White', '1996-08-27', '70506 Zachary Wells Suite'),
(100, 'Judith Booth', '2000-11-06', '9697 Norris Creek'),
(101, 'Linda Beltran', '1990-01-01', '07303 Chen Rue'),
(102, 'Rebecca Thompson', '1995-07-29', '318 Donna Island Apt.'),
(103, 'Carla Hull', '2000-10-05', '38224 Smith Isle Suite '),
(104, '40367375', '2002-08-08', '23 Oran Park');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
