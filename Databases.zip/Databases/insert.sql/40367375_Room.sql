-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 13, 2023 at 01:36 PM
-- Server version: 10.4.26-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `omcgurgan01`
--

--
-- Dumping data for table `40367375_Room`
--

INSERT INTO `40367375_Room` (`rmID`, `capacity`, `venueID`, `subjID`, `roomNo`, `type`, `status`) VALUES
(1, 50, 2, 5, 'CSB 01/020', 'conference room', 'Open'),
(2, 100, 1, 6, '16 Malone Road  01/004', 'meeting room', 'Open'),
(3, 393, 5, 2, 'DKB 0G/115', 'Lecture Theatre', 'Open'),
(4, 1000, 7, 1, 'Whitla Hall', 'Hall', 'Ready to Open'),
(5, 25, 6, 3, 'Peter Froggatt Centre 02/009', 'Classroom', 'Renovation'),
(6, 118, 3, 4, 'Ashby 03/014\r\n', 'Classroom', 'Open'),
(7, 250, 2, 2, 'CSB 02/027', 'Lecture Theatre', 'Open');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
