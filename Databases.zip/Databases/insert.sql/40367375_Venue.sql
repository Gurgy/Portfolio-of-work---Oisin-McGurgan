-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 13, 2023 at 01:40 PM
-- Server version: 10.4.26-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `omcgurgan01`
--

--
-- Dumping data for table `40367375_Venue`
--

INSERT INTO `40367375_Venue` (`venueID`, `address`, `managerName`, `country`, `status`) VALUES
(1, '16 Malone Road, Belfast BT9 5BN', 'Daniel Woo', 'Northern Ireland', 'Open'),
(2, 'Computer Sciene Building, 18 Malone Road, Belfast, BT9 5BN', 'John Mary', 'Northern Ireland', 'Open'),
(3, 'Ashby Building, Stranmillis Road, Belfast BT9 5AH', 'Alice Springer', 'Northern Ireland\r\n', 'Open'),
(4, 'Main Physics Building University Road, Belfast BT7 1NN', 'Sakil Sheer', 'Northern Ireland', 'Open'),
(5, 'David Keir Building, Malone Road, Belfast BT7 1NN', 'Andrew Moore', 'Northern Ireland', 'Open'),
(6, 'Peter Froggatt Centre, 9 College Park Eat, Belfast BT7 1PS', 'Paul Mullan', 'Northern Ireland', 'Open'),
(7, 'Whitla Hall, Queen\'s University, Belfast BT7 1NN', 'Daniel Orr', 'Northern Ireland', 'Open'),
(8, 'Lanyon Building, University Rd, Belfast BT7 1NN\r\n', 'Crystal Carter', 'Northern Ireland', 'Open'),
(9, 'Medical Biology Centre, 97 Lisburn Rd, Belfast BT9 7BL\r\n', 'Neil Samson', 'Northern Ireland', 'Open');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
