-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 13, 2023 at 01:39 PM
-- Server version: 10.4.26-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `omcgurgan01`
--

--
-- Dumping data for table `40367375_Subject`
--

INSERT INTO `40367375_Subject` (`subjID`, `subjName`, `schID`, `Programme`, `TMode`, `Date_of_Firstoffer`) VALUES
(1, 'Applied Cryptography', 1, 'Applied Cyber Security', 'Face to Face', '2023-01-01'),
(2, 'Computer Forensic', 1, 'Applied Cyber Security', 'Hybrid', '2023-05-01'),
(3, 'Penetration Testing', 1, 'Applied Cyber Security', 'Hybrid', '2023-05-16'),
(4, 'Data, Privacy and the Law', 1, 'Applied Cyber Security', 'Hybrid', '2023-07-01'),
(5, 'Web Development', 1, 'Applied Cyber Security', 'Online', '2023-08-21'),
(6, 'Project', 1, 'Applied Cyber Security', 'Face-to-Face', '2023-08-21'),
(7, 'Creative Writing', 6, 'Journalism', 'Online', '2023-08-21'),
(8, 'Mathematics', 2, 'Statistical Mathematics', 'Face-to-Face', '2023-08-21'),
(9, 'Audio Engineering', 5, 'Music Production', 'Face-to-Face', '2023-08-21'),
(10, 'Introduction to Physics', 4, 'AstroPhysics', 'Face-to-Face', '2023-08-21'),
(11, 'Mechanical Principles', 3, 'Mechanical Engineering', 'Face-to-Face', '2023-08-21'),
(12, 'Fluid Mechanics', 3, 'Material Science', 'Face-to-Face', '2023-08-21'),
(13, 'Technical Writing', 6, 'Journalism', 'Hybrid', '2023-08-21'),
(14, 'Advanced Mathematics', 2, 'Statistical Mathematics', 'Face-to-Face', '2023-08-21'),
(15, 'Aerodynamic Principles', 3, 'Aerospace Engineering', 'Online', '2023-08-21'),
(16, 'Music Composition', 6, 'Music Production', 'Face-to-Face', '2023-08-21');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
