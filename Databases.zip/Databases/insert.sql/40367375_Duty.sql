-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 13, 2023 at 01:35 PM
-- Server version: 10.4.26-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `omcgurgan01`
--

--
-- Dumping data for table `40367375_Duty`
--

INSERT INTO `40367375_Duty` (`dutyID`, `subjID`, `staffID`, `semester`, `year`) VALUES
(1, 4, 5, 'S1', 2023),
(2, 2, 6, 'S1', 2023),
(3, 3, 10, 'S2', 2024),
(4, 4, 7, 'S1', 2022),
(5, 1, 20, 's1', 2024),
(6, 5, 20, 's2', 2020),
(7, 5, 20, 's2', 2021),
(8, 6, 6, 's2', 2023),
(9, 5, 20, 's2', 2022),
(10, 5, 20, 's2', 2023),
(11, 7, 9, 's1', 2023),
(12, 8, 10, 's1', 2023),
(13, 10, 12, 's1', 2023),
(14, 11, 13, 's1', 2023),
(15, 12, 14, 's1', 2023),
(16, 13, 15, 's1', 2023),
(17, 14, 17, 's1', 2023),
(18, 14, 22, 's1', 2023),
(19, 16, 24, 's1', 2023),
(20, 2, 3, 'S1', 2023),
(21, 3, 7, 'S2', 2023),
(22, 1, 8, 'S2', 2023),
(23, 6, 6, 's2', 2022),
(24, 3, 7, 'S2', 2022),
(25, 1, 8, 'S2', 2022),
(26, 6, 6, 's2', 2021);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
