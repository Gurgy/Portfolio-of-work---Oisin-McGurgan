-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 13, 2023 at 01:38 PM
-- Server version: 10.4.26-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `omcgurgan01`
--

--
-- Dumping data for table `40367375_Staff`
--

INSERT INTO `40367375_Staff` (`staffID`, `title`, `firstName`, `lastName`, `schID`, `venueID`, `joined`, `leftD`, `current`, `salary`, `contractType`, `supervisorID`) VALUES
(1, 'Dr', 'Daniel', 'Dare', 1, 1, '2005-05-13', '2009-01-12', 0, 40000, 'Full time', 5),
(2, 'Dr', 'Sarah', 'Important', 1, 2, '2005-06-15', NULL, 1, 38990, 'Part time', 5),
(3, 'Dr', 'Alice', 'Alive', 1, 5, '2010-06-15', NULL, 1, 35600, 'Part time', 2),
(4, 'Dr', 'Xander', 'Mander', 1, 1, '2010-04-18', NULL, 1, 45790, 'Part time', 3),
(5, 'Professor', 'Jenny', 'Generator', 1, 1, '2011-12-23', NULL, 1, 68000, 'Full time', 4),
(6, 'Ms', 'Gemma', 'Hardasnails', 1, 2, '2011-08-13', NULL, 1, 70000, 'Full time', 2),
(7, 'Dr', 'Prince', 'Caspian', 1, 2, '2017-09-01', NULL, 1, 21000, 'Full time', 5),
(8, 'Mr', 'Brian', 'Knuckles', 1, 3, '2008-07-01', '2010-09-30', 0, 30000, 'Full time', 6),
(9, 'Dr', 'Bob', 'Punch', 3, 3, '2008-07-01', NULL, 1, 29000, 'Full time', 6),
(10, 'Mrs', 'Natalie', 'Nononsense', 1, 1, '2010-10-13', NULL, 1, 37890, 'Full time', 6),
(11, 'Mr', 'Euan', 'Young', 4, 4, '2017-11-01', NULL, 1, 59000, 'Part time', 7),
(12, 'Professor', 'Andrew', 'Brown', 6, 6, '2016-09-21', '2015-05-09', 0, 80420, 'Part time', 5),
(13, 'Dr', 'Mohsin', 'Burks', 4, 4, '2018-06-15', NULL, 1, 21317, 'Full time', 2),
(14, 'Mrs', 'Jadene', 'Crawford', 5, 8, '2010-06-15', NULL, 1, 56701, 'Full time', 2),
(15, 'Dr', 'Pola', 'Halliday', 6, 6, '2010-04-04', '2018-05-05', 0, 60000, 'Full time', 5),
(16, 'Dr', 'Heidi', 'Lloyd', 5, 8, '2015-11-23', NULL, 1, 49060, 'Full time', 20),
(17, 'Professor', 'Oliwia', 'Carroll', 3, 3, '2015-04-01', NULL, 1, 57210, 'Part time', 4),
(18, 'Mr', 'Ramone', 'Rose', 2, 4, '2017-01-09', NULL, 1, 25200, 'Part time', 6),
(19, 'Ms', 'Eva-rose', 'Ashley', 1, 2, '2006-01-07', NULL, 1, 60000, 'Full time', 7),
(20, 'Mrs', 'Charity', 'Mann', 3, 3, '2006-01-07', NULL, 1, 50000, 'Part time', 10),
(21, 'Mrs', 'Animee', 'Amin', 6, 8, '2007-10-13', '2015-02-17', 0, 45610, 'Full time', 6),
(22, 'Mr', 'Ryan', 'Gray', 4, 4, '2007-01-07', NULL, 1, 42040, 'Part time', 2),
(23, 'Professor', 'Niall', 'Cullinan', 1, 2, '2016-09-21', '2019-08-21', 1, 40400, 'Full time', 6),
(24, 'Mr', 'Tomas', 'Cunningham', 1, 2, '2005-06-15', NULL, 1, 35590, 'Full time', 2),
(25, 'Ms', 'Jasper', 'Thomas', 4, 4, '2010-06-15', NULL, 1, 71923, 'Part time', 20),
(26, 'Professor', 'Amy', 'Henderson', 4, 4, '2010-04-18', NULL, 1, 27500, 'Full time', 4),
(27, 'Mrs', 'Anna', 'Newman', 1, 1, '2011-12-23', NULL, 1, 74690, 'Full time', 25),
(28, 'Dr', 'Eva', 'Ward', 3, 3, '2011-12-08', NULL, 1, 27500, 'Part time', 18),
(29, 'Dr', 'Lydra', 'Cook', 2, 2, '2017-01-09', NULL, 1, 75458, 'Full time', 25),
(30, 'Mr', 'Christian', 'Clarke', 1, 1, '2008-01-07', '2020-07-10', 0, 41590, 'Full time', 6);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
